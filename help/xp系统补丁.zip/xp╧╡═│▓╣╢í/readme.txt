English
--------------------------------------------------------------------------------、
0. you must backup C:/Windows/System32/USP10.DLL file first. if install is failed,
   the system may be can not startup again.　if failed reboot the system with save
   mode and restore this file.
1. if your system exists the directory
　　C:/Program Files/Common Files/Microsoft Shared/OFFICE10/USP10.DLL or
　　C:/Program Files/Common Files/Microsoft Shared/OFFICE11/USP10.DLL
　　and older than downloaded one,
　　replace it with downloaded one. it is easy to overwrite with copy command.
2. excute InstallUsp10Only.exe and select the downloaded USP10.DLL, click update.
3. confirm C:/Windows/System32/USP10.DLL is the downloaded USP10.DLL file.

日本語
--------------------------------------------------------------------------------
0. C:/Windows/System32/USP10.DLLファイルを先にバックアップしておいてください。
　　インストールが失敗するとシステムが起動できなくなる可能性があります。この場合、セーフモードで起動してから
　　USP10.DLLを戻してください。
1.　C:/Program Files/Common Files/Microsoft Shared/OFFICE10/USP10.DLL　或いは
　　C:/Program Files/Common Files/Microsoft Shared/OFFICE11/USP10.DLL 存在して、
　　ダウンロードしたUSP10.DLL古いなら先に置き換えください。
2.　InstallUsp10Only.exeを実行して、ダウンロードしたUSP10.DLLを選べて、updateをクリックする。
	（下のほうに表示されているメッセージを無視してください。インストールする必要ありません）
3.　C:/Windows/System32/USP10.DLLがダウンロードしたUSP10.DLLファイルになっていることを確認する。

简体中文
--------------------------------------------------------------------------------
0. 先备份C:/Windows/System32/USP10.DLL文件。如果安装失败，有可能整个系统起不来。
        如果系统起不来，用安全模式启动后，恢复该文件。
1. 如果存在
   C:/Program Files/Common Files/Microsoft Shared/OFFICE10/USP10.DLL 或
　　C:/Program Files/Common Files/Microsoft Shared/OFFICE11/USP10.DLL
      先替换以上USP10.DLL文件。
2. 执行InstallUsp10Only.exe，选择下载的USP10.DLL文件，按update按钮。
       （忽略窗口下边显示的信息，不需要安装）
3. 察看C:/Windows/System32/USP10.DLL文件，确实被下载的USP10.DLL文件替换。

ᠮᠣᠩᠭᠣᠯ
--------------------------------------------------------------------------------
0. ᠲᠤᠰ ᠰᠤᠹᠲ ᠶᠢ ᠣᠷᠤᠭᠤᠯᠬᠤ ᠡᠴᠡ ᠡᠮᠦᠨ᠎ᠡ C:/Windows/System32/USP10.DLL ᠹᠠᠢᠢᠯ ᠢ ᠤᠷᠢᠳᠠ ᠪᠡᠷ ᠨᠢᠭᠡ ᠬᠣᠪᠢ ᠬᠠᠳᠠᠭᠠᠯᠠᠵᠤ ᠠᠪᠬᠤ ᠴᠢᠬᠤᠯᠠᠲᠠᠢ᠃ ᠪᠤᠷᠤᠭᠤᠳᠪᠠᠯ OS ᠪᠣᠰᠴᠤ ᠳᠡᠢᠢᠯᠡᠬᠦ ᠦᠭᠡᠢ ᠪᠣᠯᠵᠤ ᠮᠡᠳᠡᠨ᠎ᠡ᠃ OS ᠪᠣᠰᠴᠤ ᠳᠡᠢᠢᠯᠡᠬᠦ ᠦᠭᠡᠢ ᠪᠣᠯᠪᠠᠯ᠂ OS᠊ ᠢ ᠠᠶᠤᠯᠭᠦᠢ ᠬᠡᠯᠪᠡᠷᠢ ᠪᠡᠷ(safe mode) ᠪᠣᠰᠭᠠᠵᠤ ᠲᠤᠰ ᠹᠠᠢᠢᠯ ᠢ ᠪᠣᠴᠤᠭᠠᠪᠠᠯ᠂ ᠪᠣᠰᠴᠤ ᠳᠡᠢᠢᠯᠬᠦ ᠪᠣᠯᠤᠨ᠎ᠠ᠃<br>
‌1. ᠬᠡᠷᠪᠡ C:/Program Files/Common Files/Microsoft Shared/OFFICE10/USP10.DLL ᠪᠣᠶᠤ 　　C:/Program Files/Common Files/Microsoft Shared/OFFICE11/USP10.DLL ᠹᠠᠢᠢᠯ ᠪᠠᠢᠢᠪᠠᠯ ᠤᠷᠢᠳᠠ ᠪᠡᠷ ᠲᠡᠭᠦᠨ ᠢ ᠪᠠᠭᠤᠯᠭᠠᠭᠰᠠᠨUSP10.DLL᠊ ᠶᠢᠡᠷ ᠰᠣᠯᠢᠨ᠎ᠠ᠃ <br>
‌2. InstallUsp10Only.exe᠊ ᠭᠦᠢᠴᠡᠳᠭᠡᠵᠦ᠂  ᠪᠠᠭᠤᠭᠯᠭᠠᠭᠰᠠᠨ USP10.DLL᠊ ᠢ ᠰᠤᠩᠭᠤᠵᠤ, update᠊ ᠶᠢ ᠳᠠᠷᠤᠨ᠎ᠠ᠃ ᠭᠠᠷᠴᠤ ᠢᠷᠡᠭᠰᠡᠨ ᠴᠤᠩᠬᠤᠨ ᠳᠡᠭᠡᠷ᠎ᠡ OK ᠳᠠᠷᠤᠨ᠎ᠠ᠃ ᠴᠤᠩᠬᠤᠨ ᠤ ᠳᠣᠣᠷ᠎ᠠ ᠢᠯᠡᠷᠡᠵᠦ ᠪᠠᠢᠢᠭ᠎ᠠ ᠦᠭᠡ ᠪᠡᠷ ᠶᠠᠪᠤᠬᠤ ᠬᠡᠷᠡᠭ ᠦᠭᠡᠢ᠃ ᠲᠡᠷᠡ ᠮᠠᠨ ᠤ ᠮᠣᠩᠭᠣᠯ ᠳᠤ ᠭᠡᠷᠡᠭ ᠦᠭᠡᠢ᠃<br>
‌3. C:/Windows/System32/USP10.DLL ᠹᠠᠢᠢᠯ ᠪᠠᠭᠤᠯᠭᠠᠭᠰᠠᠨ USP10.DLL ᠹᠠᠢᠢᠯ ᠪᠡᠷ ᠰᠣᠯᠢᠭᠳᠠᠭᠰᠠᠨ ᠢ ᠪᠠᠢᠢᠴᠠᠭᠠᠨ᠎ᠠ᠃
